create function login(par_username character varying, par_password character varying) returns character varying
LANGUAGE plpgsql
AS $$
declare
    loc_usrnm character varying;
    loc_pwd character varying;
    loc_res character varying;
  begin
     select into loc_usrnm username, loc_pwd, password from login
       where username = par_username and password = par_password;

     if loc_usrnm isnull AND loc_pwd isnull then
       loc_res = 'Error';
     else
       loc_res = 'ok';
     end if;
     return loc_res;
  end;
$$;
