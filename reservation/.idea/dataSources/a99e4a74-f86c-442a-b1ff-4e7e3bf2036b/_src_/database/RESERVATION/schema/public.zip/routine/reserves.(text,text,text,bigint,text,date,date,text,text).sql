create function reserves(hnames text, fname text, lname text, cnum bigint, rsize text, checkins date, checkouts date, dur text, rnum text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
    loc_res text;
  BEGIN
      INSERT INTO reservation
          (hname, firstname, lastname, contactnum, roomsize, checkin, checkout, duration, roomnum)
      VALUES (hnames, fname, lname, cnum, rsize, checkins, checkouts, dur, rnum);
    loc_res = 'stored';
    return loc_res;
  END;
$$;
