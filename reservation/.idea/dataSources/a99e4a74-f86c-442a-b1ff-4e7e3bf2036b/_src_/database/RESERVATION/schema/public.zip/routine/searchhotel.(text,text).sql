create function searchhotel(par_hotelname text, random text, OUT text, OUT text, OUT text, OUT integer, OUT boolean) returns SETOF record
LANGUAGE SQL
AS $$
select hotelname, address, contact_num, price, true from "hotels" where "hotelname" ilike par_hotelname;
$$;
