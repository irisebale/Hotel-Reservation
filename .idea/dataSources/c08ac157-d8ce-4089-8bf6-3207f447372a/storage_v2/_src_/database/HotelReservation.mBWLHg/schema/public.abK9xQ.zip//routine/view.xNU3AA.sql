create function view(OUT text, OUT text, OUT text, OUT bigint, OUT text, OUT date, OUT date, OUT text, OUT text)
  returns SETOF record
language sql
as $$
select hname, firstname, lastname, contactnum, roomsize, checkin, checkout, duration, roomnum from reservation ;
$$;

