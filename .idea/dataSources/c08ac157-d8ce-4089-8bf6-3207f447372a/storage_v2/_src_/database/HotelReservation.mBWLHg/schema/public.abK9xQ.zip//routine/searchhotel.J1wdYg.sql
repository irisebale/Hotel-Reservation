create function searchhotel(par_hotelname text, random text, OUT text, OUT text, OUT bigint, OUT text, OUT boolean)
  returns SETOF record
language sql
as $$
select hotelname, address, contact_num, price, true from "hotelinfo" where "hotelname" ilike par_hotelname;
$$;

